# Motorsports Events Server 8.1.0-alpha.2-lot.4

Lot 2 incrémental : extraction du shell global MEDS.

## Démarrage Windows sans modifier ExecutionPolicy

Double-cliquer ou exécuter :

```cmd
scripts\start-clean.cmd
```

Ou depuis PowerShell :

```powershell
.\scripts\start-clean.ps1
```

## Validation

Méthode recommandée :

```powershell
npm run validate:lot2
```

Alternatives :

```cmd
scripts\test-lot2.cmd
```

```powershell
.\scripts\test-lot2.ps1
```

## Ports

```env
WEB_HOST_PORT=3000
API_HOST_PORT=3001
POSTGRES_PORT=5433
```

Ils peuvent être modifiés dans `.env` si une ancienne version est encore démarrée.

## Vérification visuelle

- navigation desktop ;
- ouverture/fermeture de la navigation sous 800 px ;
- horloge Europe/Paris ;
- badges latéraux ;
- Dashboard, Événements, Championnats et Synchronisations.

Consulter `docs/handoff/LOT-2-SHELL.md`.


## Nettoyage des anciennes versions Docker

Mode interactif recommandé :

```cmd
scripts\cleanup.cmd
```

Ou :

```powershell
npm run cleanup
```

Nettoyage complet sans confirmation, y compris les bases de test et les images :

```powershell
npm run cleanup:all
```

Options PowerShell :

```powershell
.\scripts\cleanup.ps1 -Volumes -Images -Force
```

Attention : `-Volumes` supprime les données PostgreSQL de test.

## Réinitialisation complète du lot

```cmd
scripts\reset-dev.cmd
```

Cette commande nettoie l'environnement, reconstruit les images, démarre les
conteneurs puis lance la validation du lot 2.


## Lot 4 — gestion des championnats

Le menu **Championnats** propose désormais un CRUD complet. Pour valider ce lot :

```cmd
scripts\reset-dev.cmd
scripts\test-lot3.cmd
```

Le test crée un championnat temporaire, le modifie puis le supprime.


## Lot 4

La gestion persistante des événements est disponible dans `/events`. Les clients consomment `GET /api/v1/events`; les opérations d’administration utilisent `/api/v1/admin/events`.
