# Instructions Codex — 8.1.0-alpha.2-lot.3-rev.5

Lire en premier :

1. `docs/handoff/CODEX-HANDOFF.md`
2. `docs/handoff/LOT-2-SHELL.md`
3. `docs/handoff/PROGRESS.json`
4. `docs/handoff/UI_CONTRACT.md`

## État

Le shell global est extrait dans `apps/web/src/design-system/layout`.
Les pages métier restent dans `App.tsx`.

## Interdictions

- ne pas recréer Sidebar, Topbar ou PageHeader dans une page ;
- ne pas modifier une route sans mise à jour de `navigation.ts` ;
- ne pas déclarer le lot validé avant un build et un test local ;
- ne jamais afficher un fournisseur dans une description publique ;
- préserver catégorie facultative, origine administrative et création manuelle sans fournisseur.
