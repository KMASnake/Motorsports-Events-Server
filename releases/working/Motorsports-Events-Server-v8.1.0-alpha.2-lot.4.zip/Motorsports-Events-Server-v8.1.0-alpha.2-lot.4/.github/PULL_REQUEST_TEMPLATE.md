## Résumé

## Maquette ciblée
- [ ] Dashboard
- [ ] Événements
- [ ] Championnats
- [ ] Synchronisations
- [ ] Autre

## Validation
- [ ] `npm run build --workspace @mse/web`
- [ ] `npm run build --workspace @mse/api`
- [ ] Capture avant/après jointe
- [ ] `PROGRESS.json` mis à jour
- [ ] Contraintes métier respectées
