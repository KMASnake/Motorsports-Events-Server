import type { FastifyInstance } from 'fastify';
import { randomUUID } from 'node:crypto';
import { pool } from '../lib/db.js';

export async function catalogRoutes(app: FastifyInstance): Promise<void> {
  app.get('/api/v1/circuits', async () => (await pool.query('select * from circuits order by country_code,name')).rows);
  app.get('/api/v1/events', async () => (await pool.query(`select e.*, c.name championship_name, ci.name circuit_name, ci.country_code from events e left join championships c on c.id=e.championship_id left join circuits ci on ci.id=e.circuit_id order by e.starts_at nulls last`)).rows);

  app.post('/api/v1/events', async (request, reply) => {
    const body = request.body as Record<string, unknown>;
    const id = String(body.id ?? randomUUID());
    const result = await pool.query(
      `insert into events(id,championship_id,circuit_id,name,starts_at,status) values($1,$2,$3,$4,$5,$6) returning *`,
      [id, body.championship_id ?? null, body.circuit_id ?? null, body.name, body.starts_at ?? null, body.status ?? 'scheduled']
    );
    reply.code(201);
    return result.rows[0];
  });
}
