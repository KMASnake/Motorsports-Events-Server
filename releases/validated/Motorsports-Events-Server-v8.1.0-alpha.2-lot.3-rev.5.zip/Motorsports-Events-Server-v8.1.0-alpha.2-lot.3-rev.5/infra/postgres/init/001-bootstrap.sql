create table if not exists championships (
  id text primary key,
  slug text not null unique,
  name text not null,
  short_name text,
  official_name text,
  category text,
  season integer not null default 2026,
  active boolean not null default true,
  sync_enabled boolean not null default false,
  provider_key text,
  external_id text,
  logo_url text,
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists circuits (
  id text primary key,
  name text not null,
  country_code char(2)
);

create table if not exists events (
  id text primary key,
  championship_id text references championships(id) on delete restrict,
  circuit_id text references circuits(id),
  name text not null,
  starts_at timestamptz,
  status text not null default 'scheduled'
);

insert into championships(
  id, slug, name, short_name, official_name, category, season,
  active, sync_enabled, provider_key, external_id, description
) values
  ('f1','formula-1','Formule 1','F1','FIA Formula One World Championship','Monoplace',2026,true,true,'primary','formula-1','Championnat du monde de Formule 1.'),
  ('motogp','motogp','MotoGP','MotoGP','FIM MotoGP World Championship','Vitesse moto',2026,true,true,'primary','moto-gp','Catégorie reine des Grands Prix moto.'),
  ('wrc','wrc','WRC','WRC','FIA World Rally Championship','Rallye',2026,true,false,null,null,'Championnat du monde des rallyes.')
on conflict (id) do update set
  slug=excluded.slug,
  short_name=excluded.short_name,
  official_name=excluded.official_name,
  category=excluded.category,
  season=excluded.season,
  updated_at=now();

insert into circuits(id,name,country_code) values
  ('lemans','Circuit Bugatti','FR'),
  ('silverstone','Silverstone','GB'),
  ('monza','Monza','IT'),
  ('sachsenring','Sachsenring','DE')
on conflict do nothing;

insert into events(id,championship_id,circuit_id,name,starts_at,status) values
  ('evt-001','motogp','lemans','Grand Prix de France','2026-05-10T12:00:00Z','scheduled'),
  ('evt-002','f1','silverstone','Grand Prix de Grande-Bretagne','2026-07-05T14:00:00Z','completed')
on conflict do nothing;
